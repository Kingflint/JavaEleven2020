package com.flint.eleven;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;

public class Player {
    private Texture texture;
    private float x, y;
    private float width, height;  // Scaled width and height
    private Rectangle bounds;

    // Constructor to initialize the player with x, y positions and scale
    public Player(float x, float y, float scale) {
        texture = new Texture("Player.png");
        this.x = x;
        this.y = y;

        // Apply scale to width and height
        this.width = texture.getWidth() * scale;
        this.height = texture.getHeight() * scale;
        bounds = new Rectangle(x, y, width, height);
    }

    // Constructor for default scale (1.0)
    public Player(float x, float y) {
        this(x, y, 0.5f); // Default scale of 1.0
    }

    // Update method to move the player
    public void update(float delta) {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            x -= 200 * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            x += 200 * delta;
        }

        if (x < 0) x = 0;
        if (x > Gdx.graphics.getWidth() - width) {
            x = Gdx.graphics.getWidth() - width;
        }

        bounds.setPosition(x, y);
    }

    // Method to draw the player on the screen with scaled size
    public void draw(SpriteBatch batch) {
        batch.draw(texture, x, y, width, height); // Use scaled width and height
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void dispose() {
        texture.dispose();
    }
}
