package com.flint.eleven;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.Gdx;

public class FallingObject {
    private Texture texture;
    private float x, y;
    private float speed;
    private float width, height;
    private Rectangle bounds;
    private String textureFile;
    private boolean active = true;

    public FallingObject(String textureFile) {
        this.textureFile = textureFile;
        texture = new Texture(textureFile);
        width = texture.getWidth() * 0.07f;
        height = texture.getHeight() * 0.07f;

        bounds = new Rectangle(0, 0, width, height);

        respawn();
    }

    public void update(float delta) {
        if (active) {
            y -= speed * delta;
            bounds.setPosition(x, y);

            if (y + height < 0) {
                respawn();
            }
        }
    }

    public void draw(SpriteBatch batch) {
        if (active) {
            batch.draw(texture, x, y, width, height);
        }
    }

    public void respawn() {
        x = MathUtils.random(0, Gdx.graphics.getWidth() - width);
        y = Gdx.graphics.getHeight();
        speed = MathUtils.random(100, 300);
        if (bounds != null) {
            bounds.setPosition(x, y);
        }
        active = true;
    }

    public void onCollision() {
        respawn();
    }

    public boolean isActive() {
        return active;
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void dispose() {
        if (texture != null) {
            texture.dispose();
        }
    }
}
