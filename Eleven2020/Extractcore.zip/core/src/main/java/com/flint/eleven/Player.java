package com.flint.eleven;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;

public class Player {
    private Texture texture;
    private float x, y;
    private Rectangle bounds;
    private float scale = 0.1f;
    private float width, height;

    public Player(float x, float y) {
        texture = new Texture("Player.png");

        width = texture.getWidth() * scale;
        height = texture.getHeight() * scale;

        this.x = (Gdx.graphics.getWidth() - width) / 2;
        this.y = 1;

        bounds = new Rectangle(this.x, this.y, width, height);
    }

    public void update(float delta) {
        if (Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            x -= 400 * delta;
        }
        if (Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            x += 400 * delta;
        }

        if (x < 0) x = 0;
        if (x > Gdx.graphics.getWidth() - width) {
            x = Gdx.graphics.getWidth() - width;
        }

        bounds.setPosition(x, y);
    }

    public void draw(SpriteBatch batch) {
        batch.draw(texture, x, y, width, height);
    }

    public boolean checkCollision(Rectangle otherBounds)
        return bounds.overlaps(otherBounds) &&
            otherBounds.y <= (bounds.y + bounds.height) &&
            otherBounds.y > bounds.y;
    }

    public Rectangle getBounds() {
        return bounds;
    }

    public void dispose() {
        texture.dispose();
    }
}
