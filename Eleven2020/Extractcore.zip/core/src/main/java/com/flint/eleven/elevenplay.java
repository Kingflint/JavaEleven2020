package com.flint.eleven;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;

public class elevenplay extends ApplicationAdapter {
    private SpriteBatch batch;
    private Player player;
    private FallingObject fallingBasketball;
    private FallingObject fallingApple;
    private BitmapFont font;
    private int score;
    private Texture background; 
    private float screenWidth;
    private float screenHeight;

    @Override
    public void create() {
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.setColor(Color.WHITE);
        score = 0;

        screenWidth = Gdx.graphics.getWidth();
        screenHeight = Gdx.graphics.getHeight();

        background = new Texture("background2.png");

        player = new Player(0, 0);

        fallingBasketball = new FallingObject("basketball.png");
        fallingApple = new FallingObject("apple.png");
    }

    @Override
    public void render() {
        update(Gdx.graphics.getDeltaTime());

        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        batch.begin();

        batch.draw(background, 0, 0, screenWidth, screenHeight);

        player.draw(batch);
        fallingBasketball.draw(batch);
        fallingApple.draw(batch);

        font.draw(batch, "Score: " + score, 10, Gdx.graphics.getHeight() - 10);

        batch.end();
    }

    private void update(float delta) {
        player.update(delta);

        fallingBasketball.update(delta);
        fallingApple.update(delta);


        checkCollisions();
    }

    private void checkCollisions() {
        if (fallingBasketball.isActive() && player.checkCollision(fallingBasketball.getBounds())) {
            fallingBasketball.onCollision();
            score += 2;
        }

        if (fallingApple.isActive() && player.checkCollision(fallingApple.getBounds())) {
            fallingApple.onCollision();
            score += 1;
        }
    }

    @Override
    public void resize(int width, int height) {
        screenWidth = width;
        screenHeight = height;
    }

    @Override
    public void dispose() {
        batch.dispose();
        player.dispose();
        fallingBasketball.dispose();
        fallingApple.dispose();
        font.dispose();
        background.dispose();
    }
}
